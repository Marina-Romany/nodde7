const express = require('express')
const router = express.Router()
const post = require ('../models/post')


router.get('/' , async(req , res) =>{
    const posts =  await post.find()
    res.render("index", {posts} )
})


router.get('/create' , async(req , res) =>{
    return res.render('create')
})

router.post('/create' , async(req , res)=>{
    const {title , content} = req.body
     let post = new this.post({title , content})

try{
    post = await post.save()
} catch{
     return res.status(400).send(err)
}
    return res.redirect('/posts')
})


router.get('/delete/:id' , async(req,res)=>{
    const{id} = rec.params
    const post = await post.findByIdAndDelete(id)
    if (!post) return res.status(404).send('the post id not found')

   
    return res.redirect('/posts')
})


router.get('/edit/:id' , async(req , res)=>{
    const {id} = req.params
    const post = await this.post.findById(id)
    return res.render('edit' , {post})
})


router.post('/edit/:id' , async(req , res)=>{
    const {id} = req.params
    const{title , content} = req.body

    const post = await post.findByIdAndUpdate(id , {title , content} ,{new : true} )

    return res.redirect('/posts')
})


module.exports = router
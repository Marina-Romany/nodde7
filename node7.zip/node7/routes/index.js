module.exports = (app) =>{
    app.use('/posts' , require('./posts'))
}